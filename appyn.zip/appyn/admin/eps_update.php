<?php 
header('Content-Type: text/html; charset=utf-8');
define('WP_USE_THEMES', false);
global $wpdb;
require('../../../../wp-load.php');

if( !isset($_POST['post_id']) ) {
	exit;
}

if( empty(appyn_options( 'apikey' )) ) {
	$output['info'] = __( 'Error: La API Key es inválida.', 'appyn' );
	echo json_encode($output);
	exit;
}

$output = array();
$post_id = $_POST['post_id'];
$url_app = ( !empty(get_post_meta( $post_id, 'datos_informacion', true )) ) ? get_post_meta( $post_id, 'datos_informacion', true ) : array();

$url_app = $url_app['consiguelo'];

if( empty($url_app) ){ 
	$url_app = $_POST['url_app'];
}

if( empty($url_app) ){
    $output['info'] = __( 'Error: No hay URL de Playstore en este post', 'appyn' );
    $output['error_field'] = 'consiguelo';
    echo json_encode($output);
    exit;
}

if( !get_http_response_code( $url_app ) ) {
	$output['info'] = __( 'Error: Al parecer la URL no existe. Verifique nuevamente.', 'appyn' );
	$output['error_field'] = 'consiguelo';
	echo json_encode($output);
	exit;
}

$edcgp_sapk = appyn_options( 'edcgp_sapk', true );

$url = "https://api.themespixel.net/?apikey=".appyn_options( 'apikey' )."&website=".urlencode(get_bloginfo('url') )."&app=".urlencode($url_app);

if( !$edcgp_sapk ) {
	$url .= "&apk=true";
}

$bot = go_curl($url);

$bot = json_decode($bot, true);

if( isset($bot['error_web']) ) {
	$output['info'] = __( 'Error: Este dominio no está habilitado.', 'appyn' );
	echo json_encode($output);
	exit;
}

if( isset($bot['error_apikey']) ) {
	$output['info'] = __( 'Error: La API Key es inválida.', 'appyn' );
	echo json_encode($output);
	exit;
}

$bot = $bot['app'];

$datos['nombre']  				= $bot['title'];
$datos['contenido']  			= $bot['content'];
$datos['descripcion']  			= $bot['description'];
$datos['fecha_actualizacion']  	= $bot['date'];
$datos['last_update'] 		 	= $bot['last_update'];
$datos['version']  				= $bot['version'];
$datos['requerimientos']  		= $bot['requires'];
$datos['novedades']  			= $bot['whats_new'];
$datos['imagecover']  			= $bot['icon'];
$datos['video']  				= $bot['video'];
$datos['tamano']  				= $bot['size'];
$datos['categoria']  			= $bot['cat'];
$datos['desarrollador']  		= $bot['developer'];
$datos['pago']  				= $bot['is_pay'];

$edcgp_post_status 			= appyn_options( 'edcgp_post_status' );
$edcgp_create_category 		= appyn_options( 'edcgp_create_category' );
$edcgp_create_tax_dev 		= appyn_options( 'edcgp_create_tax_dev' );
$edcgp_extracted_images 	= appyn_options( 'edcgp_extracted_images' ) ? appyn_options( 'edcgp_extracted_images' ) : 5;
$edcgp_sapk 				= appyn_options( 'edcgp_sapk' );

$n = 0;
foreach($bot['screenshots'] as $screenshot) { 
	if( $n < $edcgp_extracted_images ) {
		$datos['imagenes'][$n] = $screenshot;
	}
	$n++;
}	

if( $edcgp_create_category != 1 ) {
	// Agregar categoría
	require_once( ABSPATH . '/wp-admin/includes/taxonomy.php');
		$cat_defaults = array(
			'cat_ID' 	=> 0,
			'cat_name' => $datos['categoria'],
			'taxonomy' => 'category');
		wp_insert_category( $cat_defaults );
		$term_id = term_exists($datos['categoria'], 'category');
}
	

$my_post = array(
    'ID'       		=> $post_id,
	'post_title'    => wp_strip_all_tags( $datos['nombre'] ),
	'post_content'  => $datos['contenido'],
	'post_author'   => get_current_user_id(),
);
$my_post['post_status'] = get_post_status($post_id);

if( $edcgp_create_category != 1 ) {
	$my_post['post_category'] = array($term_id);
}

$dca = ( get_option( 'appyn_dedcgp_descamp_actualizar' ) ) ? get_option( 'appyn_dedcgp_descamp_actualizar' ) : array();

if( in_array('app_title', $dca) )
	unset($my_post['post_title']);

if( in_array('app_content', $dca) )
	unset($my_post['post_content']);

wp_update_post( $my_post, true );

if( !is_wp_error($post_id) ) {
    $output['post_id'] = $post_id;
	$info = __( 'Información actualizada.', 'appyn' )."\n";
	$output['info_text'] = '<i class="fa fa-check"></i> '.sprintf(__( 'Entrada "%s" actualizada.', 'appyn' ), $datos['nombre']);
}
if( $edcgp_create_category != 1 ) {
	// Agregar categoría
	wp_set_post_terms($post_id, $term_id, 'category');
}

if( $edcgp_create_tax_dev != 1 ) {
	// Agregar taxonomía
	$post_datos_informacion = str_replace(',', '', $datos['desarrollador']);
	wp_insert_term( $post_datos_informacion, 'dev' );
	$term_id = term_exists( $post_datos_informacion, 'dev' );
	wp_set_post_terms( $post_id, $post_datos_informacion, 'dev' );
}
px_upload_image();


$datos_informacion = array(
	'descripcion' 			=> $datos['descripcion'],
	'version' 				=> $datos['version'],
	'tamano' 				=> $datos['tamano'],
	'fecha_actualizacion' 	=> $datos['fecha_actualizacion'],
	'last_update'		 	=> $datos['last_update'],
	'requerimientos' 		=> $datos['requerimientos'],
	'novedades' 			=> $datos['novedades'],
	'app_status'	 		=> 'updated',
	'consiguelo' 			=> $url_app,
);

if( $bot['is_pay'] ) {
	$datos_informacion['offer']['price'] = 'pago';
}

update_post_meta($post_id, "datos_informacion", $datos_informacion);
update_post_meta($post_id, "datos_video", array('id' => $datos['video']));
update_post_meta($post_id, "datos_imagenes", $datos['imagenes']);

if( get_option( 'appyn_edcgp_rating' ) ) {
	
	$rating = $bot['rating'];

	update_post_meta($post_id, "new_rating_users", $rating['users']);
	update_post_meta($post_id, "new_rating_count", $rating['total']);
	update_post_meta($post_id, 'new_rating_average', $rating['average'] );
}

if( !$edcgp_sapk && !in_array('app_download_links', $dca) ) {
	if( $bot['apk'] ) {

		$re = '/(?<=[?&]id=)[^&]+/m';
		$str = $url_app;
		preg_match_all($re, $str, $matches, PREG_SET_ORDER, 0);
		$idps = $matches[0][0];

		$output['apk_info'] = array(
			'post_id' => $post_id,
			'idps' 	  => $idps,
			'date' 	  => $bot['last_update'],
		);

		$output['apk_info']['url'] = $bot['apk'];

		$tsr = ( appyn_options('edcgp_sapk_server') == 2 ) ? __( 'Google Drive', 'appyn' ) : __( 'mi servidor', 'appyn' ); 

		if( px_check_apk_obb($bot['apk']) ) {
			$output['apk_info']['text'] = '<i class="fa fa-upload"></i> '. sprintf( __( 'Se encontró un archivo APK y OBB. Subiendo a %s en ZIP...', 'appyn' ), $tsr);
		} else {
			$output['apk_info']['text'] = '<i class="fa fa-upload"></i> '. sprintf( __( 'Se encontró un archivo APK. Subiendo a %s...', 'appyn' ), $tsr);
			if( array_key_exists('zip', $bot['apk']) ) {
				$output['apk_info']['text'] = '<i class="fa fa-upload"></i> '. sprintf(__( 'Se encontró un archivo ZIP. Subiendo a %s...', 'appyn' ), $tsr);
			}
		}
	}
}

$output['info'] = $info;
echo json_encode($output);