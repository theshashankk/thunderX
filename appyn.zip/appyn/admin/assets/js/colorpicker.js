(function( $ ) {
    $(function() {
		$('.colorpicker').wpColorPicker();         
    });
})( jQuery );