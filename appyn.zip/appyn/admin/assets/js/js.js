if(window.location.hash) {
	var section = document.getElementById('panel_theme_tpx');
	var sections = section.getElementsByClassName('section');
	for(var i=0;i<sections.length;i++){
		if( sections[i].dataset.section == location.hash.replace('#', '') ) {
			sections[i].classList.add("active");
		} else {
			sections[i].classList.remove("active");
		}
	}
	document.querySelectorAll("a[href='"+location.hash+"']")[0].parentElement.classList.add("active");		
} else {
	if( document.querySelectorAll("a[href='#general']")[0] )
		document.querySelectorAll("a[href='#general']")[0].parentElement.classList.add("active");	
}

jq_bx = jQuery.noConflict();
jq_bx(function($) {
	
	var boxes_count = $('#boxes-content .boxes-a').size();
	$('#add-boxes').on('click', function(e){
		e.preventDefault();
		if( tinyMCEPreInit.mceInit.novedades ) {
			My_New_Global_Settings =  tinyMCEPreInit.mceInit.novedades;
		} else {
			My_New_Global_Settings =  tinyMCEPreInit.mceInit.content;
		}
		var request = $.ajax({
			url: ajaxurl,
			type:"POST",
			data : {
				action : 'boxes_add',
				keycount : boxes_count,
			},
			success: function(data){
				$('#boxes-content').append(data);
				tinymce.init(My_New_Global_Settings); 
				tinyMCE.execCommand('mceAddEditor', false, "custom_boxes-"+boxes_count); 
				quicktags({id : "custom_boxes-"+boxes_count});
				boxes_count++;	
			}
		});
		request.fail(function(jqXHR, textStatus) {
			console.log( "Request failed: " + textStatus );
		});				
	});
	$(document).on('click', '.delete-boxes', function(){
		$(this).parents('.boxes-a').remove();
	});

	var exists_apk = false;
	$(document).on('click', '#wp-admin-bar-appyn_actualizar_informacion', function(e){
		e.preventDefault();
		var confirm = window.confirm( text_confirm_update );
		if( confirm === false ) {
			return;
		}
		$('#extract-result').remove();
		$(this).addClass('wait');
		var post_id = $('#post_ID').val();
		var url_app = $('#consiguelo').val();
		var request = $.ajax({
 			url: url_eps_update,
			type : 'POST',
			data: {
				post_id: post_id,
				url_app: url_app,
			}
		});
		$(window).bind('beforeunload', function(){
			return 'Are you sure you want to leave?';
		});
		request.done(function (data, textStatus, jqXHR){
			var data = JSON.parse(data);
			if( data.post_id ) {
				$('.wrap, .interface-interface-skeleton__editor').prepend('<div id="box-info-import">'+
					'<ul id="extract-result">'+
						'<li style="color:#10ac10;">'+data.info_text+'</li>'+
					'</ul>'+
				'</div>');

				if( data.apk_info ) {
					exists_apk = true;
					$('#extract-result').append('<li class="apk-result">'+data.apk_info.text+'</li>');

					var request_ajax = $.ajax({
						url: ajaxurl,
						type: "POST",
						data: {
							action: "action_upload_apk",
							apk: data.apk_info.url,
							post_id: data.apk_info.post_id,
							idps: data.apk_info.idps,
							date: data.apk_info.date,
						},
					});
					
					request_ajax.done(function (data_apk, textStatus, jqXHR){
						var data_apk = JSON.parse(data_apk);
						if( data_apk.info ){
							$('.apk-result').html('<li class="apk-result" style="color:#10ac10;">'+data_apk.info+'</li>');
						}
						
						$(window).unbind('beforeunload');
						alert(data.info);
						location.reload();
					});

					request_ajax.fail(function (jqXHR, textStatus, errorThrown){
						console.error(
							"The following error occurred: "+
							textStatus, errorThrown
						);
					});
					request_ajax.always(function () {						
						$('#wp-admin-bar-appyn_actualizar_informacion').removeClass('wait');
					});
				}
			} else {
				if( data.info ){
					$('.wrap, .interface-interface-skeleton__editor').prepend('<div id="box-info-import">'+
						'<ul id="extract-result">'+
							'<li style="color:red;">'+data.info+'</li>'+
						'</ul>'+
					'</div>');
				}
				$('#wp-admin-bar-appyn_actualizar_informacion').removeClass('wait');
			}

			if( data.error_field ) {
				var of = $('#'+data.error_field).offset();
				$('html, body').animate({scrollTop: of.top - 100}, 500);
				$('#'+data.error_field).focus();
				$('#'+data.error_field).css('border-color', 'red');
				$('#'+data.error_field).on('click', function(){
					$(this).removeAttr('style');
				});
			}
			if( !exists_apk ) {
				$('#wp-admin-bar-appyn_actualizar_informacion').removeClass('wait');
				$(window).unbind('beforeunload');
				alert(data.info);
				location.reload();
			}
		});
		request.fail(function (jqXHR, textStatus, errorThrown){
			console.error(
				"The following error occurred: "+
				textStatus, errorThrown
			);
		});
	});

	$(document).on("click", "#importar", function(event){
		event.preventDefault();
		$('#extract-result').remove();
		var $this = $(this);
		$this.parent().find(".spinner").addClass("active");
		var url_app = $("#url_googleplay").val();
		var request = $.ajax({
			url: url_eps_publish,
			type:"POST",
			data: {
				"url_app":url_app
			},
		});
		request.done(function (data, textStatus, jqXHR){
			var data = JSON.parse(data);
			if( data.post_id ) {
				$('.extract-box').after('<div style="font-weight:500;">'+
					'<ul id="extract-result">'+
						'<li style="color:#10ac10;">'+data.info_text+'</li>'+
					'</ul>'+
				'</div>');

				if( data.apk_info ) {
					exists_apk = true;
					$('#extract-result').append('<li class="apk-result">'+data.apk_info.text+'</li>');

					var request_ajax = $.ajax({
						url: ajaxurl,
						type: "POST",
						data: {
							action: "action_upload_apk",
							apk: data.apk_info.url,
							post_id: data.apk_info.post_id,
							idps: data.apk_info.idps,
							date: data.apk_info.date,
						},
					});
					
					request_ajax.done(function (data, textStatus, jqXHR){
						var data_apk = JSON.parse(data);
						if( data_apk.info ){
							$('.apk-result').html('<li class="apk-result" style="color:#10ac10;">'+data_apk.info+'</li>');
						}
					});

					request_ajax.fail(function (jqXHR, textStatus, errorThrown){
						console.error(
							"The following error occurred: "+
							textStatus, errorThrown
						);
					});
					request_ajax.always(function () {						
						$this.parent().find(".spinner").removeClass("active");
					});
				}
			} else {
				if( data.info ){
					$('.extract-box').after('<div style="font-weight:500;">'+
						'<ul id="extract-result">'+
							'<li style="color:red;">'+data.info+'</li>'+
						'</ul>'+
					'</div>');
				}
				$this.parent().find(".spinner").removeClass("active");
			}
		});
		request.fail(function (jqXHR, textStatus, errorThrown){
			console.error(
				"The following error occurred: "+
				textStatus, errorThrown
			);
		});
		request.always(function () {
			if( !exists_apk ) {
				$this.parent().find(".spinner").removeClass("active");
			}
			$('#url_googleplay').val('');
		});
	}); 

	
	$( "ul.px-orden-cajas" ).sortable();
	$( "ul.px-orden-cajas" ).disableSelection();

	$('#panel_theme_tpx #menu ul li a').on('click', function(e){
		$('#panel_theme_tpx .section').removeClass('active');
		
		if(!$(''+$(this).attr('href')+'').hasClass('active')){
			var url = $(this).attr('href').replace('#', '');
			$('.section[data-section='+url+']').addClass('active');
		}

		$(this).parent().parent().find('li').removeClass('active');
		$(this).parent().addClass('active');
		$(window).on('popstate',function(event) {
			$('#panel_theme_tpx .section').removeClass('active');
			$('.section[data-section='+location.hash.replace('#','')+']').addClass('active');
		});
	});

	$('.switch-show').each(function(index, element){
		var el = $(this).data('sshow');

		if( $(this).find('input').is(':checked') )
			$("."+el).show();
		else
			$("."+el).hide();
	});

	$(document).on('change', '.switch-show input', function(){
		var el = $(this).parent().data('sshow');

		if( $(this).is(':checked') )
			$("."+el).show();
		else
			$("."+el).hide();
	});

	$(document).on('click', '#button_google_drive_connect', function(e){
		if( !$('#gdrive_client_id').val().length || !$('#gdrive_client_secret').val().length ) {
			$('#gdrive_client_id').css('border-color', 'red');
			$('#gdrive_client_secret').css('border-color', 'red');
			e.preventDefault();
		}
	});

	$(document).on('click', '#gdrive_client_id, #gdrive_client_secret', function(){
		$(this).removeAttr('style');
	});

	$(document).on('click', '.autocomplete_info_download_apk_zip', function(e){
		e.preventDefault();

		tinyMCE.get('apps_info_download_apk').setContent($('#default_apps_info_download_apk').html());
		
		tinyMCE.get('apps_info_download_zip').setContent($('#default_apps_info_download_zip').html());

	});
});
