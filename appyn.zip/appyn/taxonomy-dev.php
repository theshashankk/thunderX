<?php get_header(); ?>
	<div class="container">
    	<div class="section">
            <div class="title-section">
            	<?php echo __( 'Desarrollador', 'appyn' ); ?>: <?php echo single_tag_title("", false); ?>
            </div>
            <div class="ct_description"><?php echo @tag_description(); ?></div>
            <?php
            $i = 1;
            if( have_posts() ):
            ?> 
            <div class="bloque-apps">
                <?php
				while( have_posts() ) : the_post();
                    get_template_part( 'template-parts/loop/app' );
                    if( $i == 6) {
                        if( !wp_is_mobile( ) )
                            echo '</div>'.ads("ads_home").'<div class="bloque-apps">';
                    }
                    $i++; 
                endwhile;
                ?>
            </div>
            <?php
            paginador();
            endif; ?>
    	</div>
   </div>
<?php get_footer(); ?>