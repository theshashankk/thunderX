<?php get_header(); ?>
	<div class="container">
		<?php echo do_action( 'do_home' ); ?>
   </div>
<?php get_footer(); ?>