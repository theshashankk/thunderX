<?php get_header(); ?>
	<div class="container">
		<div class="aplication-single">
			<?php 
			if ( have_posts() ) : while ( have_posts() ) : the_post(); 	
				
				$get_download = get_query_var( 'download' );
			?>
				<div class="box<?php echo ($get_download == "true" || $get_download == "redirect" || $get_download == "links") ? ' box-download': ''; ?>">
					<?php
					if( $get_download ) { 
						get_template_part( 'template-parts/single-infoapp-get' );
					} else {
						get_template_part( 'template-parts/single-infoapp' );
					} 
					?>
					<div class="right s2 box-social">
						<?php echo px_botones_sociales(); ?>
					</div>
				</div>
				<div id="box-report" class="box">
					<div class="box-content">
						<form>
							<a href="javascript:void(0)" class="close-report"><i class="fa fa-close"></i></a>
							<h2><?php echo __( 'Reportar esta app', 'appyn'); ?></h2>
							<label><input type="radio" name="report-opt" value="1" checked required> <span><?php echo __( 'No funcionan los enlaces de descarga', 'appyn' ); ?></span></label>
							<label><input type="radio" name="report-opt" value="2"> <span><?php echo __( 'Hay una nueva versión', 'appyn'); ?></span></label>
							<label><input type="radio" name="report-opt" value="3"> <span><?php echo __( 'Otros', 'appyn' ); ?></span></label>
							<p><textarea placeholder="<?php echo __( 'Detalle del reporte (Opcional)', 'appyn' ); ?>"  name="report-details" spellcheck="off"></textarea></p>
							<p><input type="submit" class="br-submit" value="<?php echo __( 'Reportar', 'appyn' ); ?>"></p>
						</form>
					</div>
				</div>
				<?php 
				echo ads("ads_single_top"); 
				echo do_action( 'seccion_cajas' );

				$cvn = (get_option('appyn_versiones_no_cajas')) ? get_option('appyn_versiones_no_cajas') : array(1);
				if( ( $post->post_parent == 0 || !in_array( 'comentarios', $cvn ) ) ) {
					comments_template();
				}
			endwhile; endif; ?>
		</div>
		<?php get_sidebar(); ?>
	</div>
<?php get_footer(); ?>