<?php $datos_download = get_datos_download(); ?>
<div class="right s2">
    <?php px_breadcrumbs(); ?>
    <?php 
    $datos_informacion = get_post_meta($post->ID, 'datos_informacion', true); ?>
    <h1 class="box-title">
        <?php 
        $title = get_the_title(); 
        echo ( str_replace( @$datos_informacion['version'], '', $title ) );  
        ?>
    </h1><?php echo ( !empty(@$datos_informacion['version']) ) ? '<h4 class="version">'.@$datos_informacion['version'].'</h4>' : ''; ?>
    
    <div class="clear"></div>

    <div class="meta-cats"><?php echo px_pay_app(); ?><?php the_category(); ?></div>

    <?php echo (!empty($datos_informacion['descripcion'])) ? '<div class="descripcion">'.$datos_informacion['descripcion'].'</div>' : ''; ?>
</div>
<div class="left s1">
    <?php 
    echo px_post_thumbnail('thumbnail', $post, true);
    if( link_button_download_apk() ) {
        if( isset($datos_informacion['consiguelo']) ) {
            if( strpos($datos_informacion['consiguelo'], 'microsoft.com') !== false || empty($datos_informacion['consiguelo'])) {
                echo '<a href="'.link_button_download_apk().'" class="downloadAPK" rel="nofollow" title="'. __( 'Descargar APK', 'appyn' ).'"'.((is_amp_px()) ? ' on="tap:download.scrollTo(duration=400)"' : '').'><i class="fa fa-download"></i> '. __( 'Descargar APK', 'appyn' ).'</a>';
            } else {
                echo '<a href="'.link_button_download_apk().'" class="downloadAPK" rel="nofollow" title="'. __( 'Descargar', 'appyn' ).'"'.((is_amp_px()) ? ' on="tap:download.scrollTo(duration=400)"' : '').'><i class="fa fa-download"></i> '. __( 'Descargar', 'appyn' ).'</a>';
            }
        }
    } 
    ?>

    <?php show_rating(); ?>

    <?php if( ! is_amp_px() ) { ?>
    <div class="link-report"><a href="javascript:void(0)"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> <?php echo __( 'Reportar', 'appyn' ); ?></a></div>
    <?php } ?>
</div>
<div class="right s2">
    <?php if( !empty($datos_informacion) ) { ?>
    <div class="box-data-app">
        <div class="left data-app">
            <?php
            if( !empty($datos_informacion['desarrollador']) ) {
                echo '<span><b>'.__( 'Desarrollador', 'appyn' ).'</b><br>';
                echo $datos_informacion['desarrollador'];
            } else {
                $dev_terms = wp_get_post_terms( $post->ID, 'dev', array('fields' => 'all'));
                if( !empty($dev_terms) ) {
                    echo '<span><b>'.__( 'Desarrollador', 'appyn' ).'</b><br>';
                    echo '<a href="'.get_term_link($dev_terms[0]->term_id).'">'.$dev_terms[0]->name.'</a>';
                }
            }
            echo '</span>';
            echo (!empty($datos_informacion['version'])) ? '<span><b>'.__( 'Versión', 'appyn' ).'</b><br>'.$datos_informacion['version'].'</span>' : ''; ?>
        </div><div class="left data-app">
            <?php 
            echo (!empty($datos_informacion['fecha_actualizacion'])) ? '<span><b>'.__( 'Actualización', 'appyn' ).'</b><br>'.$datos_informacion['fecha_actualizacion'].'</span>' : ''; 
            echo (!empty($datos_informacion['requerimientos'])) ? '<span><b>'.__( 'Requerimientos', 'appyn' ).'</b><br>'.$datos_informacion['requerimientos'].'</span>' : ''; 
            ?>
        </div><div class="left data-app">
            <?php 
            echo (!empty($datos_informacion['tamano'])) ? '<span><b>'.__( 'Tamaño', 'appyn' ).'</b><br>'.$datos_informacion['tamano'].'</span>' : '';
            $imggp = get_store_app();
            
            echo (!empty($datos_informacion['consiguelo'])) ? '<span><b>'.__( 'Consíguelo en', 'appyn' ).'</b><br> <a href="'.$datos_informacion['consiguelo'].'" target="_blank">'.$imggp.'</a></span>' : ''; 
            ?>
        </div>
    </div>
    <?php } ?>
</div>