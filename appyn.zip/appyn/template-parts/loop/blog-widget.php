<li><a href="<?php echo the_permalink(); ?>"><div class="bghover"></div>
           	<?php 
	  if(has_post_thumbnail()) {
		  the_post_thumbnail('miniatura'); 
	  } else {
		  echo px_noimage();
	  } ?>
       <div class="s2">
	   	<span class="title"><?php the_title(); ?></span>
        <span class="date"><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php the_time( get_option( 'date_format' ) ); ?></span>
       </div>
</a></li>