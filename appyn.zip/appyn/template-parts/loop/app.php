<?php 
$datos_informacion = get_post_meta($post->ID, 'datos_informacion', true); 
$version = @$datos_informacion['version']; 
if(!$version) $version = '--'; else $version = $version; ?>
<div class="bloque-app">
	<a href="<?php the_permalink(); ?>">
		<div class="bloque-imagen"><?php echo px_post_thumbnail(); ?></div>
		<span class="title"><?php the_title(); ?></span>
		<?php echo app_developer(); ?>
		<?php echo app_date(); ?>
        <div class="meta">
        	<span class="version"><?php echo __( 'Versión', 'appyn' ); ?> <?php echo $version; ?></span>
            <?php show_rating(0); ?>
        </div>
	</a>
</div>