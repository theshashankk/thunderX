<li><a href="<?php echo the_permalink(); ?>"><?php echo px_post_thumbnail(); ?></a>
	<div class="s2">
			<a href="<?php echo the_permalink(); ?>" class="title"><?php the_title(); ?></a>
			<?php px_blog_postmeta(); ?>
			<div class="excerpt"><?php the_excerpt(); ?></div>
	</div>
</li>