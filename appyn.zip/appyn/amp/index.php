<?php get_header(); ?>
	<div class="container">
        <?php 
        $i = 1;
        $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
        $home_limite = get_option( 'appyn_home_limite' );
        $home_limite = ( empty( $home_limite ) ) ? '12' : $home_limite;
        $args = array( 'paged' => $paged, 'posts_per_page' => $home_limite);
        $home_posts_orden = get_option( 'appyn_home_posts_orden' );
        if( $home_posts_orden == 'modified' ){
            $args['orderby'] = 'modified';
        }
        elseif( $home_posts_orden == 'rand' ){
            $args['orderby'] = 'rand';
        }		
        $query = new WP_Query( $args);
        if( $query->have_posts() ) : ?>
        <div class="section">
            <div class="title-section"><?php echo __( 'Últimas aplicaciones de nuestra web', 'appyn' ); ?></div>
            <div class="bloque-apps">
                <?php while( $query->have_posts() ) : $query->the_post(); ?>
                <?php get_template_part( 'template-parts/loop/app' ); ?>
                <?php if( $i == 6) { ?>
                    <?php if( !wp_is_mobile( ) ) { echo ads("ads_home"); } ?> 
                <?php } ?><?php $i++; endwhile; ?>
                <?php paginador( $query, $home_limite); ?>
            </div>
        </div>
        <?php endif; wp_reset_query(); 
        
        $blog_posts_home_limite = get_option( 'appyn_blog_posts_home_limite' );
        $blog_posts_home_limite = ( empty( $blog_posts_home_limite ) ) ? '4' : $blog_posts_home_limite;
        $query = new WP_Query(array( 'post_type' => 'blog', 'posts_per_page' => $blog_posts_home_limite ) );
        if( $query->have_posts() ) : ?>
            <div class="section">
                <div class="title-section">Blog</div>
                <div class="bloque-blogs">
                    <?php while( $query->have_posts() ) : $query->the_post();
                        get_template_part( 'template-parts/loop/blog-home' ); 
                        endwhile; 
                        if( $query->found_posts > $blog_posts_home_limite ):?>
                            <a href="<?php echo get_post_type_archive_link( 'blog' ); ?>" class="more"><?php echo __( 'Ver más', 'appyn' ); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        <?php
        endif;
        wp_reset_query(); 		
        $categorias_home = get_option( 'appyn_categories_home' );
        if( !empty( $categorias_home ) ) { 
            $h = 1; 
            foreach( $categorias_home as $cat) :
                $cat = get_term( $cat, 'category' );
                if( function_exists( 'icl_object_id' ) ){ //WPML
                    $cat_id_wpml = icl_object_id( $cat->term_id,'category',false,ICL_LANGUAGE_CODE);
                    if( !empty( $cat_id_wpml ) )
                        $cat = get_term_by( 'id', $cat_id_wpml, 'category' );
                }
                $i = 1;
                $categories_home_limite = get_option( 'appyn_categories_home_limite' );
                $categories_home_limite = ( empty( $categories_home_limite ) ) ? '10' : $categories_home_limite;
                $cpost = new WP_Query(array( 'posts_per_page' => $categories_home_limite, 'cat' => $cat->term_id ) );
                if( $cpost->have_posts() ) : 
                ?>
                <div class="section">
                    <div class="title-section"><?php echo $cat->name; ?></div>
                    <div class="bloque-apps">
                        <?php while( $cpost->have_posts() ) : $cpost->the_post(); ?>
                        <?php get_template_part( 'template-parts/loop/app' ); ?>
                        <?php if( $h == 1 && $i == 6) { ?>
                            <?php if( !wp_is_mobile( ) ) { echo ads("ads_home"); } ?> 
                        <?php } ?><?php $i++; endwhile; ?>
                        <?php if( $cpost->found_posts > $categories_home_limite ) { ?>
                        <a href="<?php echo get_term_link( $cat->term_id, 'category' ); ?>" class="more"><?php echo __( 'Ver más', 'appyn' ); ?></a>
                        <?php } ?>
                    </div>
                </div>
                <?php endif; wp_reset_query(); ?>
            <?php $h++; endforeach; ?>
    <?php } ?>
    </div>
<?php get_footer(); ?>