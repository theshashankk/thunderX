<?php
add_action( 'wp_ajax_ajax_searchbox', 'ajax_searchbox' );  
add_action( 'wp_ajax_nopriv_ajax_searchbox', 'ajax_searchbox' );
function ajax_searchbox() {
	global $wpdb, $post;
	$searchtext = trim($_POST['searchtext']);	
	$return = '';
	$args = array( 'post_type' => 'post', 'wpse18703_title' => $searchtext, 'posts_per_page' => -1, 'post_status' => 'publish' );
	if( get_option( 'appyn_versiones_mostrar_buscador') == 0 ) {
		$args['post_parent'] = 0;
	} 
	$query = new WP_Query( $args );
	if( $query->have_posts() ): 
		
		while( $query->have_posts() ): $query->the_post();
			$datos_informacion = get_post_meta($post->ID, 'datos_informacion', true);
			$return .= '<li><a href="'.get_the_permalink().'" style="display:flex">';
			$return .= px_post_thumbnail( 'miniatura', $post->ID );
			$return .= '<div>'.get_the_title();
			if( !empty($datos_informacion['version']) ) {
				$return .= '<br><span>';
				if( !empty($datos_informacion['version']) ) {
					$return .= __( 'Versión', 'appyn' ).': '.$datos_informacion['version'];
				}
				$dev_terms = wp_get_post_terms( $post->ID, 'dev', array('fields' => 'all'));
				if( !empty($dev_terms) ) { 
					$return .= '<br>'.__( 'Desarrollador', 'appyn' ).': '.$dev_terms[0]->name;
				}
				$return .= '</span>';
                
			}
			$return .= '</div></a></li>';
			endwhile;
		
	endif;
	echo json_encode($return);
	die(); 
}
add_action( 'wp_ajax_post_rating', 'post_rating' ); 
add_action( 'wp_ajax_nopriv_post_rating', 'post_rating' );
function post_rating() {
	global $wpdb;
	$post_id = $_POST['post_id'];
	$rating_count = round($_POST['rating_count']);
	if(user_no_voted()){
		$a = (get_post_meta( $post_id, 'new_rating_count', true ) ? get_post_meta( $post_id, 'new_rating_count', true ) : 0) + $rating_count; 
		$b = (get_post_meta( $post_id, 'new_rating_users', true ) ? get_post_meta( $post_id, 'new_rating_users', true ) : 0) + 1; 
		update_post_meta( $post_id, 'new_rating_users', $b );
		update_post_meta( $post_id, 'new_rating_count', $a );
		update_post_meta( $post_id, 'new_rating_average', number_format(($a / $b), 1, ".", "") );

		if( !isset($_COOKIE['nw_rating']) ) {
			setcookie("nw_rating", $post_id, time()+(24*365), "/");
		} else {
			$nr = explode(",",$_COOKIE['nw_rating']);
			$nr[] = $post_id;
			setcookie("nw_rating", implode(",", $nr), time()+(24*365), "/");
		}
	}
	$ar = count_rating($post_id);
	$ar['users'] = number_format($ar['users'], 0, ",", ",");
	echo json_encode($ar);	
	die();
}

add_action( 'wp_ajax_boxes_add', 'ajax_boxes_add' );  
add_action( 'wp_ajax_nopriv_boxes_addw', 'ajax_boxes_add' );
function ajax_boxes_add(){
	$content = $_POST['content'];
	$box_key = $_POST['keycount'];
	$textarea_name = $_POST['textarea_name'];
	echo '<div class="boxes-a">
		<p><input type="text" id="custom_boxes-title-'.$box_key.'" class="widefat" name="custom_boxes['.$box_key.'][title]" value="" placeholder="'.__( 'Título para la caja', 'appyn' ).'"></p>
		<p>'; ?>
	<?php
	wp_editor($content, 'custom_boxes-'.$box_key, array('textarea_name' => 'custom_boxes['.$box_key.'][content]', 'textarea_rows' => 5,'quicktags' => array('buttons' => 'strong,em,link,block,del,ins,img,ul,ol,li,code,close'))
); ?>
	<?php echo '</p>
		<p><a href="javascript:void(0)" class="delete-boxes button">'.__( 'Borrar caja', 'appyn' ).'</a></p>
		</div>';
	die();
}


add_action( 'wp_ajax_app_report', 'px_app_report' );  
add_action( 'wp_ajax_nopriv_app_report', 'px_app_report' );
function px_app_report() {
	parse_str( $_POST['serialized'], $output );
	
	$continue = false;
	$recaptcha_site = get_option( 'appyn_recaptcha_site' );
	$recaptcha_secret = get_option( 'appyn_recaptcha_secret' );	
	if( $recaptcha_site && $recaptcha_secret ) {
		$secret = $recaptcha_secret;
		$token = $output['token'];
		$ch = curl_init("https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$token);
		curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$response = curl_exec($ch);
		curl_close($ch);
		$response = json_decode($response, true);
		if( $response['success'] === true && $response['action'] == $output['action'] ) {
			$continue = true;
		}
	} else {
		$continue = true;
	}
	$info_new = array(
		'option' => $output['report-opt'],
		'details' => $output['report-details'],
	);
	if( $continue ) {
		$url = wp_get_referer();
		$post_id = url_to_postid( $url ); 
		$info = array();
		$info_db = get_post_meta( $post_id, 'px_app_report', true );
		if( $info_db ) {
			$info = json_decode( $info_db, true );
		}
		$info[] = $info_new;
		update_post_meta( $post_id, 'px_app_report', json_encode($info) );
		echo 1;
	} else {
		echo 0;
	}
	die();
}

add_action( 'wp_ajax_action_upload_apk', 'y_action_upload_apk' );  
add_action( 'wp_ajax_nopriv_action_upload_apk', 'y_action_upload_apk' );
function y_action_upload_apk() {
	
	$post_id 	= $_POST['post_id'];
	$idps 		= $_POST['idps'];
	$apk 		= $_POST['apk'];
	$update 	= $_POST['date'];

	px_upload_apk($post_id, $idps, $apk, $update);
	$info = array('info' => '<i class="fa fa-check"></i> '.__( 'Archivo subido y asignado al post.', 'appyn' ));
	echo json_encode($info);
	die;
}
