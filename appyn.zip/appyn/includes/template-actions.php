<?php

add_action( 'subheader', 'func_subheader' );

function func_subheader() {
	if( is_404() ) return;

	if( is_home() ) { ?>
	<div id="subheader">
		<div class="imgbg">
			<?php echo cover_header(); ?>
		</div>
		<div class="subcontainer">
			<?php $titulo_p = appyn_options( 'titulo_principal'); 
				if ( !empty( $titulo_p ) ) echo '<h1>'.$titulo_p.'</h1>';  ?>
			<?php $descripcion_p = appyn_options( 'descripcion_principal'); 
				if ( !empty( $descripcion_p ) ) echo '<h2>'.$descripcion_p.'</h2>'; ?>
			<div id="searchBox">
				<form action="<?php bloginfo("url"); ?>">
					<input type="text" name="s" placeholder="<?php echo __( 'Buscar una aplicación', 'appyn' ); ?>" required autocomplete="off" id="sbinput" aria-label="Search">
					<button role="button" aria-label="Search"><i class="fa fa-search" aria-hidden="true"></i></button>
				</form>
				<ul></ul>
			</div>
			<?php echo px_header_social(); ?>
		</div>
	</div>
	<?php } else { ?>
	<div id="subheader" class="np">
		<div id="searchBox">
			<form action="<?php bloginfo('url'); ?>">
				<input type="text" name="s" placeholder="<?php echo __( 'Buscar una aplicación', 'appyn' ); ?>" required autocomplete="off" id="sbinput">
				<button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
			</form>
			<ul></ul>
		</div>
		<?php echo px_header_social(); ?>
	</div>
	<?php }
}

add_action( 'do_home', 'func_action_home_mq' );

function func_action_home_mq() {
	global $post;
	$mas_calificadas = get_option('appyn_mas_calificadas');
	if(!empty($mas_calificadas)){
		$mas_calificadas_limite = get_option('appyn_mas_calificadas_limite');
		$mas_calificadas_limite = (empty($mas_calificadas_limite)) ? '5' : $mas_calificadas_limite;
		
		$args = array( 'posts_per_page' => $mas_calificadas_limite, 'meta_key' => 'new_rating_users', 'orderby' => 'meta_value_num' );			

		$iamc = ( get_option( 'appyn_versiones_mostrar_inicio_apps_mas_calificadas' ) ) ? get_option( 'appyn_versiones_mostrar_inicio_apps_mas_calificadas' ) : 0 ;
		
		if( $iamc == 1 ) {
			$args['post_parent'] = 0;
		}
		
		$query = new WP_Query( $args );

		if( $query->have_posts() ): ?>
    	<div class="section">
            <div class="title-section"><?php echo __( 'Aplicaciones más calificadas', 'appyn' ); ?></div>
        	<div id="slidehome" class="px-carousel pxcn">
				<div class="px-carousel-nav">
					<button type="button" role="presentation" class="px-prev" aria-label="Left"><i class="fa fa-angle-left" aria-hidden="true"></i></button>
					<button type="button" role="presentation" class="px-next" aria-label="Right"><i class="fa fa-angle-right" aria-hidden="true"></i></button>
				</div>
				<div class="px-carousel-wrapper">
					<div class="px-carousel-container">
				<?php
				while( $query->have_posts() ) : $query->the_post();
					if( !$post ) continue; ?>

					<div class="px-carousel-item"><?php get_template_part('template-parts/loop/app-slider'); ?></div>
				<?php endwhile; ?>
					</div>
				</div>
            </div>
        </div>
		<?php endif; wp_reset_postdata(); 
	}
}

add_action( 'do_home', 'func_action_home' );

function func_action_home() {
	if( have_posts() ) : 
	$i = 1;

	if( appyn_options( 'home_hidden_posts') ) return;
?>
	<div class="section">
		<div class="title-section"><?php echo __( 'Últimas aplicaciones de nuestra web', 'appyn' ); ?></div>
		<div class="bloque-apps">
			<?php
			while( have_posts() ) : the_post();
				get_template_part( 'template-parts/loop/app' );
				if( $i == 6) {
					if( !wp_is_mobile( ) )
						echo '</div>'.ads("ads_home").'<div class="bloque-apps">';
				}
				$i++; 
			endwhile;
			?>
		</div>
		<?php paginador(); ?>
	</div>
<?php
	endif; wp_reset_query(); 	
}

add_action( 'do_home', 'func_action_home_blog' );

function func_action_home_blog() {	
	$blog_posts_home_limite = get_option( 'appyn_blog_posts_home_limite' );
	$blog_posts_home_limite = ( empty( $blog_posts_home_limite ) ) ? '4' : $blog_posts_home_limite;
	$query = new WP_Query(array( 'post_type' => 'blog', 'posts_per_page' => $blog_posts_home_limite ) );
	if( $query->have_posts() ) : ?>
		<div class="section">
			<div class="title-section">Blog</div>
			<div class="bloque-blogs">
				<?php while( $query->have_posts() ) : $query->the_post();
					get_template_part( 'template-parts/loop/blog-home' ); 
					endwhile; 
					if( $query->found_posts > $blog_posts_home_limite ):?>
						<a href="<?php echo get_post_type_archive_link( 'blog' ); ?>" class="more"><?php echo __( 'Ver más', 'appyn' ); ?></a>
				<?php endif; ?>
			</div>
		</div>
	<?php
	endif;
	wp_reset_query(); 
}

add_action( 'do_home', 'func_action_home_categories' );

function func_action_home_categories() {
	global $wp_query;
	$categorias_home = get_option( 'appyn_categories_home' );
	if( !empty( $categorias_home ) ) { 
		$h = 1; 
		foreach( $categorias_home as $cat) :
			$cat = get_term( $cat, 'category' );
			if( function_exists( 'icl_object_id' ) ){ //WPML
				$cat_id_wpml = icl_object_id( $cat->term_id,'category',false,ICL_LANGUAGE_CODE);
				if( !empty( $cat_id_wpml ) )
					$cat = get_term_by( 'id', $cat_id_wpml, 'category' );
			}
			$i = 1;
			$categories_home_limite = get_option( 'appyn_categories_home_limite' );
			$categories_home_limite = ( empty( $categories_home_limite ) ) ? '10' : $categories_home_limite;

			$args = array( 'posts_per_page' => $categories_home_limite, 'cat' => $cat->term_id );			

			$categories_home_versiones = ( get_option( 'appyn_versiones_mostrar_inicio_categorias' ) ) ? get_option( 'appyn_versiones_mostrar_inicio_categorias' ) : 0 ;

			if( $categories_home_versiones == 1 ) {
				$args['post_parent'] = 0;
			}

			query_posts($args);

			if( have_posts() ) : 
			?>
			<div class="section">
				<div class="title-section"><?php echo $cat->name; ?></div>
				<div class="bloque-apps">
					<?php
					while( have_posts() ) : the_post();
					
						get_template_part( 'template-parts/loop/app' );
						if( $h == 1 && $i == 6 ) {
							if( !wp_is_mobile( ) )
								echo '</div>'.ads("ads_home").'<div class="bloque-apps">';
						}
						$i++; 
					endwhile;
					?>
				</div>
				<?php if( $wp_query->found_posts > $categories_home_limite ) { ?>
					<p><a href="<?php echo get_term_link( $cat->term_id, 'category' ); ?>" class="more"><?php echo __( 'Ver más', 'appyn' ); ?></a></p>
				<?php } ?>
			</div>
			<?php endif; wp_reset_query(); ?>
		<?php $h++; endforeach; ?>
   <?php } 
}


add_action( 'seccion_cajas', 'func_seccion_cajas' );

function func_seccion_cajas() {
	global $post;
	$oc = ( get_option( 'appyn_orden_cajas' ) ) ? get_option( 'appyn_orden_cajas' ) : NULL;
	$get_download = get_query_var( 'download' );
	
	if( $post->post_parent != 0 ) { // En versiones
		if( $oc ) {
			foreach( $oc as $k => $a ) {
				if( activate_versions_boxes($k) ) {
					do_action( 'func_caja_'.$k );
				} else {
					if( $get_download ) { 
						if( activate_internal_page_boxes($k) ) {
							do_action( 'func_caja_'.$k );
						}
					}
				}
			}
		} else {
			order_default('versions');
		}

	} else {
		if( $oc ) {
			foreach( $oc as $k => $a ) {
				if( $get_download ) { 
					if( activate_internal_page_boxes($k) ) {
						do_action( 'func_caja_'.$k );
					}
				} else {
					do_action( 'func_caja_'.$k );
				}
			}
		 } else {
			order_default();
		}
	}
}

function order_default($t = '') {
	
	if( $t == "versions" ) {
		do_action( 'func_caja_versiones' );
			
		if( activate_versions_boxes('descripcion') ) {
			do_action( 'func_caja_descripcion' );
		}
			
		if( activate_versions_boxes('ads_single_center') ) {
			do_action( 'func_caja_ads_single_center' );
		}

		if( activate_versions_boxes('novedades') ) {
			do_action( 'func_caja_novedades' );
		}

		if( activate_versions_boxes('imagenes') ) {
			do_action( 'func_caja_imagenes' );
		}

		if( activate_versions_boxes('video') ) {
			do_action( 'func_caja_video' );
		}
		
		if( activate_versions_boxes('enlaces_descarga') ) {
			do_action( 'func_caja_enlaces_descarga' );
		}

		if( activate_versions_boxes('relacionadas') ) {
			do_action( 'func_caja_apps_relacionadas' );
		}
		
		if( activate_versions_boxes('apps_desarrollador') ) {
			do_action( 'func_caja_apps_desarrollador' );
		}

		if( activate_versions_boxes('cajas_personalizadas') ) {
			do_action( 'func_caja_cajas_personalizadas' );
		}

		if( activate_versions_boxes('tags') ) {
			do_action( 'func_caja_tags' );
		}
	} else {
		do_action( 'func_caja_versiones' );
		do_action( 'func_caja_descripcion' );
		do_action( 'func_caja_ads_single_center' );
		do_action( 'func_caja_novedades' );
		do_action( 'func_caja_imagenes' );
		do_action( 'func_caja_video' );
		do_action( 'func_caja_enlaces_descarga' );
		do_action( 'func_caja_apps_relacionadas' );
		do_action( 'func_caja_apps_desarrollador' );
		do_action( 'func_caja_cajas_personalizadas' );
		do_action( 'func_caja_tags' );
	}
}

add_action( 'func_caja_enlaces_descarga', 'func_caja_enlaces_descarga' );

function func_caja_enlaces_descarga() {
	global $post;

	if( !download_links_normal() ) return;

	$datos_download = get_datos_download($post->ID);

	if( !is_array($datos_download) ) return;

	if( $datos_download['option'] == "direct-link" ) return;

	if( $datos_download['option'] == "direct-download" ) return;

	if( empty($datos_download[0]['link']) ) return;

	$option_download = get_option( 'appyn_download_links' );

	?>
	<div id="download" class="box">
		<h2 class="box-title"><?php echo __( 'Enlaces de descarga', 'appyn' ); ?></h2>
		<?php
		foreach( $datos_download as $val ) :
			if( empty($val['texto']) || empty($val['link']) ) continue;
			?>
		<a href="<?php echo $val['link']; ?>" target="_blank" class="downloadAPK dapk_b"><i class="fa fa-download"></i> <?php echo $val['texto']; ?></a>
		<?php endforeach; 
		echo px_info_install();
		?>
	</div>
	<?php
}

add_action( 'func_caja_descripcion', 'func_caja_descripcion' );

function func_caja_descripcion() {
	global $post; ?>
	<div id="descripcion" class="box">
		<h2 class="box-title"><?php echo __( 'Descripción', 'appyn' ); ?></h2>
		<div class="entry">
			<div class="entry-limit">
				<?php px_the_content(); ?>
			</div>
		</div>
	</div>
<?php
}

add_action( 'func_caja_ads_single_center', 'func_caja_ads_single_center' );

function func_caja_ads_single_center() {
	echo ads("ads_single_center");
}

add_action( 'func_caja_versiones', 'func_caja_versiones', false );

function func_caja_versiones($full = false) {
	global $wp_query, $wpdb, $post;
	
	$versiones_cantidad_post = ( get_option( 'appyn_versiones_cantidad_post' ) ) ? get_option( 'appyn_versiones_cantidad_post' ) : 5;
	$args = array( 
			'post_parent' => $post->ID, 
			'posts_per_page' => $versiones_cantidad_post,
			'post_status' => 'publish',
	);
	if( $full ) {
		$args['posts_per_page'] = -1;
	}
	if( $post->post_parent != 0 ) {
		$args['post_parent'] = $post->post_parent;
		$args['post__not_in'] = array($post->ID);
		$post_add = get_post($post->post_parent);
	}

	$versiones = new WP_Query( $args );
	if( $versiones->have_posts() || isset($post_add) ) : 
	?>
	<div id="versiones" class="box">
		<h2 class="box-title"><?php echo __( 'Versiones', 'appyn' ); ?></h2>
		<div class="box-content">
			<table style="margin:0;">
				<thead>
					<tr>
						<th><?php echo __( 'Versión', 'appyn' ); ?></th>
						<th><?php echo __( 'Peso', 'appyn' ); ?></th>
						<th><?php echo __( 'Requerimientos', 'appyn' ); ?></th>
						<th style="width:100px"><?php echo __( 'Fecha', 'appyn' ); ?></th>
					</tr>
				</thead>
				<tbody>
			<?php 
			$date_change = array(
				'enero' => '01',
				'febrero' => '02',
				'marzo' => '03',
				'abril' => '04',
				'mayo' => '05',
				'junio' => '06',
				'julio' => '07',
				'agosto' => '08',
				'setiembre' => '09',
				'octubre' => '10',
				'noviembre' => '11',
				'diciembre' => '12',
				' de ' => '-',
			);
			if( $post->post_parent != 0 ) {
				$inf = get_post_meta( $post_add->ID, 'datos_informacion', true );
				if( is_array($inf) ) {
				echo '<tr>
						<td><a href="'.get_permalink($post_add->ID).'">'.(( !empty($inf['version']) ) ? $inf['version'] : '-').'</a></td>
						<td>'.(( !empty($inf['tamano']) ) ? $inf['tamano'] : '-').'</td>
						<td>'.(( !empty($inf['requerimientos']) ) ? $inf['requerimientos'] : '-').'</td>
						<td>'.(( !empty($inf['fecha_actualizacion']) ) ? date_i18n( 'd/m/Y', strtotime(strtr($inf['fecha_actualizacion'], $date_change)) ) : '-').'</td>
					</tr>';		
				}	
			}	

			while( $versiones->have_posts() ) : $versiones->the_post();
				$inf = get_post_meta( $post->ID, 'datos_informacion', true );
				if( is_array($inf) ) {
					echo '<tr>
							<td><a href="'.get_permalink($post->ID).'">'.(( !empty($inf['version']) ) ? $inf['version'] : '-').'</a></td>
							<td>'.(( !empty($inf['tamano']) ) ? $inf['tamano'] : '-').'</td>
							<td>'.(( !empty($inf['requerimientos']) ) ? $inf['requerimientos'] : '-').'</td>
							<td>'.(( !empty($inf['fecha_actualizacion']) ) ? date_i18n( 'd/m/Y', strtotime(strtr($inf['fecha_actualizacion'], $date_change)) ) : '-').'</td>
						</tr>';		
				}			
			endwhile; wp_reset_query(); ?>
				</tbody>
			</table>
		</div>
		<?php
		if( !$full ) {
		if( $versiones->found_posts > $versiones_cantidad_post ) { ?>
		<p><a href="<?php echo versions_permalink(); ?>" class="readmore"><?php echo __( 'Ver más versiones', 'appyn' ); ?></a></p>
		<?php } 
		} ?><br>
	</div>
	<?php endif; wp_reset_query(); 
} 

add_action( 'func_caja_novedades', 'func_caja_novedades' );

function func_caja_novedades() {
	global $post; 
	$datos_informacion = get_post_meta($post->ID, 'datos_informacion', true);

	if( empty($datos_informacion['novedades']) ) return;

	?>
	<div id="novedades" class="box">
		<h2 class="box-title"><?php echo __( 'Novedades', 'appyn' ); ?></h2>
		<div class="box-content">
			<?php echo wpautop( $datos_informacion['novedades'] ); ?>
		</div>
	</div>
	<?php
} 

add_action( 'func_caja_imagenes', 'func_caja_imagenes' );

function func_caja_imagenes() { 
	global $post;
	$datos_imagenes = get_post_meta($post->ID, 'datos_imagenes', true);
	$datos_imagenes = @array_map('trim', $datos_imagenes); 
	$datos_imagenes = @array_filter($datos_imagenes, create_function('$a','return $a!=="";'));

	if( !is_array($datos_imagenes) ) return;
	
	if(count($datos_imagenes) == 0 ) return;

	?>
	<div class="box imagenes">
		<h2 class="box-title"><?php echo __( 'Imágenes', 'appyn' ); ?></h2>
		<div id="slideimages" class="px-carousel" data-title="<?php the_title(); ?>">
			<?php 
			if( is_amp_px() ) { ?>
			<amp-carousel height="300" controls layout="fixed-height" type="slides">
			<?php
			$i = 0; 
			foreach($datos_imagenes as $imagen) {
				if(strpos($imagen, 'googleusercontent.com') !== false || strpos($imagen, 'ggpht.com') !== false) {
					$last_pos = strrpos($imagen, '=');
					$imagen= substr($imagen, 0, $last_pos)."=h305";
					$imagen_big = substr($imagen, 0, $last_pos)."=h650";
				} else {
					$imagen_id = get_image_id($imagen);
					if(empty($imagen_id)){
						$imagen_big = $imagen;
						$imagen = $imagen;
					} else {
						$imagen_big = $imagen;
						$imagen = wp_get_attachment_image_src($imagen_id, 'medium');	
						$imagen = $imagen[0];
					}
				}
				?>
				<amp-img src="<?php echo $imagen; ?>" layout="fill"
					height="300"
					alt="a sample image"></amp-img>
			<?php } ?>
			</amp-carousel>
			<?php
			} else { ?>
			<div class="px-carousel-nav disabled"><button type="button" role="presentation" class="px-prev disabled"><i class="fa fa-angle-left" aria-hidden="true"></i></button><button type="button" role="presentation" class="px-next disabled"><i class="fa fa-angle-right" aria-hidden="true"></i></button></div>
			<div class="px-carousel-wrapper">
				<div class="px-carousel-container">
					<?php $i = 0; 
					foreach($datos_imagenes as $imagen) {
						if(strpos($imagen, 'googleusercontent.com') !== false || strpos($imagen, 'ggpht.com') !== false) {
							$last_pos = strrpos($imagen, '=');
							$imagen= substr($imagen, 0, $last_pos)."=h305";
							$imagen_big = substr($imagen, 0, $last_pos)."=h650";
						} else {
							$imagen_id = get_image_id($imagen);
							if(empty($imagen_id)){
								$imagen_big = $imagen;
								$imagen = $imagen;
							} else {
								$imagen_big = $imagen;
								$imagen = wp_get_attachment_image_src($imagen_id, 'medium');	
								$imagen = $imagen[0];
							}
						}
						$appyn_lazy_loading = ( get_option('appyn_lazy_loading') ) ? get_option('appyn_lazy_loading') : NULL;
						if( $appyn_lazy_loading == 1 ) {
							$image_blank = get_template_directory_uri().'/images/blank.png';
							$color_theme = get_option( 'appyn_color_theme' );
							$color_theme_principal = get_option( 'appyn_color_theme_principal' );
							if( is_dark_theme_active() ) {
								$image_blank = get_template_directory_uri().'/images/blank-d.png';
							}
							echo '<div class="px-carousel-item"><img class="lazyload" src="'.$image_blank.'" data-src="'.$imagen.'" data-big-src="'.$imagen_big.'" alt="'.get_the_title().' '.($i + 1).'"></div>';
						} else {
							echo '<div class="px-carousel-item"><img src="'.$imagen.'" data-big-src="'.$imagen_big.'" alt="'.get_the_title().' '.($i + 1).'"></div>'; 
						}
						$i++;
					}
					?>
				</div>
			</div>
			<?php } ?>
		</div>
	</div> 
<?php 
} 

add_action( 'func_caja_video', 'func_caja_video' );

function func_caja_video() {
	global $post,$datos_video;
	$datos_video = get_post_meta($post->ID, 'datos_video', true); 

	if( empty($datos_video['id']) ) return;

	?>
	<div class="box">
		<h2 class="box-title"><?php echo __( 'Video', 'appyn' ); ?></h2>
		<div class="iframeBoxVideo" data-id="<?php echo $datos_video['id']; ?>">
		<?php
		if( is_amp_px() ) {
			echo '<amp-youtube data-videoid="'.$datos_video['id'].'" layout="responsive" width="560" height="315"></amp-youtube>';
		} else {
			$appyn_lazy_loading = ( get_option('appyn_lazy_loading') ) ? get_option('appyn_lazy_loading') : NULL;
			if( $appyn_lazy_loading == 1 ) {
			?>
				<iframe width="730" height="360" src="<?php echo get_template_directory_uri(); ?>/admin/index.php" data-src="https://www.youtube.com/embed/<?php echo $datos_video['id']; ?>" style="border:0; overflow:hidden;" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen class="lazyload"></iframe>
			<?php } else { ?>
				<iframe width="730" height="360" src="https://www.youtube.com/embed/<?php echo $datos_video['id']; ?>" style="border:0; overflow:hidden;" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			<?php }
		} ?>
		</div>
	</div>
	<?php
}

add_action( 'func_caja_apps_relacionadas', 'func_caja_apps_relacionadas' );

function func_caja_apps_relacionadas() {
	global $post;
	$args = array(
		'post_type' => 'post',
		'posts_per_page' => 5, 
		'post__not_in' => array($post->ID), 
		'post_parent' => 0, 
		'orderby' => 'relevance' 
	);
	$apps_related_type = ( get_option( 'appyn_apps_related_type' ) ) ? get_option( 'appyn_apps_related_type' ) : array(); 

	if( !is_array($apps_related_type) ) return;
	
	if( in_array('cat', $apps_related_type) || empty($apps_related_type) ) {
		$cats = get_the_category($post->ID);
		$list_cats_id = array();
		foreach( $cats as $c ) {
			$list_cats_id[] = $c->term_id;
		}
		$args['category__in'] = $list_cats_id;
	} 
	if( in_array('tag', $apps_related_type) ) {
		$tags = get_the_tags($post->ID);
		$list_tags_id = array();
		foreach( $tags as $t ) {
			$list_tags_id[] = $t->term_id;
		}
		$args['tag__in'] = $list_tags_id;
	} 
	if( in_array('title', $apps_related_type) ) {
		$args['s'] = get_the_title();
	} 
	if( in_array('random', $apps_related_type) ) {
		$args['orderby'] = 'rand';
	}

	$query = new WP_Query( $args );
	if( $query->have_posts() ) : ?>
		<div class="box relacionados">
			<h2 class="box-title"><?php echo __( 'Apps relacionadas', 'appyn' ); ?></h2>
			<div class="bloque-apps">
			<?php while( $query->have_posts() ) : $query->the_post();
			get_template_part( 'template-parts/loop/app-related' ); 
			endwhile; ?>
			</div>
		</div>			
	<?php
	endif;
	wp_reset_query();
} 

add_action( 'func_caja_cajas_personalizadas', 'func_caja_cajas_personalizadas' );

function func_caja_cajas_personalizadas() {
	global $post;
	$custom_boxes = get_post_meta( $post->ID, 'custom_boxes', true );

	if( empty($custom_boxes) ) return;

	foreach($custom_boxes as $box_key => $box_value) { 
		if( !empty( $box_value['title'] ) || !empty( $box_value['content'] ) ) { ?>
			<div id="box-<?php echo $box_key; ?>" class="box personalizadas">
				<h2 class="box-title"><?php echo $box_value['title']; ?></h2>
				<div class="box-content"><?php echo apply_filters('the_content', stripslashes($box_value['content']) ); ?></div>
			</div>
	<?php } 
	}
}

add_action( 'func_caja_apps_desarrollador', 'func_caja_apps_desarrollador' );

function func_caja_apps_desarrollador() { 
	global $post;

	$dev_terms = wp_get_post_terms( $post->ID, 'dev', array('fields' => 'all'));

	if( !isset($dev_terms[0]->slug) ) return;

	$query = new WP_Query( array('post_type' => 'post', 'posts_per_page' => 5, 'post__not_in' => array($post->ID), 'post_parent' => 0, 'tax_query' => array(
		array(
			'taxonomy' => 'dev',
			'field'    => 'slug',
			'terms'    => $dev_terms[0]->slug,
		),
	) ) );
	if( $query->have_posts() ) { ?>
	<div class="box relacionados">
		<h2 class="box-title"><?php echo __( 'Apps del desarrollador', 'appyn' ); ?></h2>
		<div class="bloque-apps">
		<?php while( $query->have_posts() ) : $query->the_post();
		get_template_part( 'template-parts/loop/app-related' ); 
		endwhile; ?>
		</div>
	</div>
	<?php } 
	wp_reset_query(); 
} 

add_action( 'func_caja_tags', 'func_caja_tags' );

function func_caja_tags() { 
	global $post;
	$post_tags = wp_get_post_tags( $post->ID );
	
	if( empty($post_tags) ) return;

	?>
	<div id="tags" class="box etiquetas">
		<h2 class="box-title"><?php echo __( 'TAGS', 'appyn' ); ?></h2>
		<?php the_tags( '', '' ); ?>
	</div> 
	<?php
}

add_action( 'init', 'px_verify_return_gdrive' );

function px_verify_return_gdrive() {
	$code = isset($_GET['code']) ? $_GET['code'] : null;
	$scope = isset($_GET['scope']) ? $_GET['scope'] : null;

	if( $code && $scope ) {
		$client = get_Client();
		if( $client ) {
			$token = $client->fetchAccessTokenWithAuthCode($code);

			$client->setAccessToken($token);

			update_option('appyn_gdrive_token', json_encode($token));
			header("Location: ".admin_url('admin.php?page=appyn_panel#edcgp'));
			exit;
		}
	}
}

add_action( 'admin_init', 'admin_init_url_action' );

function admin_init_url_action() {

	$action = isset($_GET['action']) ? $_GET['action'] : NULL;
	
	if( $action == "google_drive_connect" ) {

		$client = get_Client();
		if( $client ) {
			if (!get_option('appyn_gdrive_token')) {
				header("Location: ".$client->createAuthUrl());
				exit;
			}
		}
	}

	if( $action == "new_gdrive_info" ) {
		delete_option( 'appyn_gdrive_token' );
		header("Location: ". admin_url('admin.php?page=appyn_panel#edcgp'));
		exit;
	}

	if( $action == 'info_server' ) {
		echo "allow_url_fopen = " .( ( ini_get('allow_url_fopen') ) ? '1' : '0' )."<br>";
		echo "max_execution_time = " .ini_get('max_execution_time')."<br>";
		echo "max_input_time = " .ini_get('max_input_time')."<br>";
		echo "memory_limit = " .ini_get('memory_limit')."<br>";
		echo "post_max_size = " .ini_get('post_max_size')."<br>";
		echo "upload_max_filesize = " .ini_get('upload_max_filesize')."<br>";
		exit;
	}
}