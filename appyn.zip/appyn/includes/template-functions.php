<?php
function count_rating($post_id){
	global $wpdb;
	$array = array();
	$rating_count = ( get_post_meta( $post_id, 'new_rating_count', true ) ) ? get_post_meta( $post_id, 'new_rating_count', true ) : 0;
	$users = ( get_post_meta( $post_id, 'new_rating_users', true ) ) ? get_post_meta( $post_id, 'new_rating_users', true ) : 0;
	$average = ( get_post_meta( $post_id, 'new_rating_average', true ) ) ? get_post_meta( $post_id, 'new_rating_average', true ) : 0;

	$array['average'] = $average;
	$array['users'] =  $users;
	$array['count'] =  $rating_count;
	
	return $array;	
}

function user_no_voted(){
	global $wpdb, $post;
	$ip = $_SERVER['REMOTE_ADDR'];
	if( !isset($_COOKIE['nw_rating']) ) 
		return true;

	$nr = explode(",",$_COOKIE['nw_rating']);
	if( !in_array($post->ID, $nr) ) {
		return true;
	}
}

function show_rating($calificar = 1){
	global $post;
	$count_rating = count_rating($post->ID); ?>
		<div class="box-rating<?php if(wp_is_mobile()) echo " movil"; if(!user_no_voted() || $calificar == 0) echo " voted";  ?>" data-post-id="<?php echo $post->ID; ?>">
		<span class="rating">
			<?php
			if($calificar == 1){ ?>
			<span class="ratings-click" title="<?php echo ( !user_no_voted() ) ? __( 'Calificación', 'appyn' ).": ".$count_rating['average']." ".__( 'estrellas', 'appyn' ): ''; ?>">
				<span class="rating-click r1" data-count="1"></span>
				<span class="rating-click r2" data-count="2"></span>
				<span class="rating-click r3" data-count="3"></span>
				<span class="rating-click r4" data-count="4"></span>
				<span class="rating-click r5" data-count="5"></span>
				</span>
			<?php } ?><span class="stars" style="width:<?php echo $count_rating['average'] * 10 * 2; ?>%"></span></span> 
			<?php
			if($calificar == 1){ ?><span class="text-rating"><b><?php echo $count_rating['average']; ?></b>/5</span>
				<span class="rating-text"><?php 
				if($count_rating['users'] > 0) {
					echo __( 'Votos', 'appyn' ).': '.number_format($count_rating['users'], 0, ',', ',');
				} else {
					echo __( 'No hay votos', 'appyn' ); 
				} ?></span>
			<?php } ?>
		</div>	
<?php	
}

function get_image_id($image_url) {
	global $wpdb;
	$attachment = $wpdb->get_col("SELECT ID FROM $wpdb->posts WHERE guid LIKE '%$image_url%'"); 
	return $attachment[0]; 
}

function ads($ads){
	if( is_404() ) return;

	$ads_output = '';
	$ads_pc = get_option( 'appyn_'.$ads );
	$ads_movil = get_option( 'appyn_'.$ads.'_movil' );
	$ads_amp = get_option( 'appyn_'.$ads.'_amp' );
	$ads_h = '<aside class="ads '.$ads.'">';
	$ads_h .= appyn_options('ads_text_above') ? '<small>'.appyn_options('ads_text_above').'</small>': '';
	if( is_amp_px() ) {
		if( !empty($ads_amp) ) {
			$ads_output = $ads_h.$ads_amp;
			$ads_output .= '</aside>';
		}
	} else {
		if( !empty($ads_pc) && !wp_is_mobile()) { 
			$ads_output = $ads_h.$ads_pc;
			$ads_output .= '</aside>';
		}
		elseif(!empty($ads_movil) && wp_is_mobile()) {
			$ads_output = $ads_h.$ads_movil;
			$ads_output .= '</aside>';
		}
	}
	return stripslashes($ads_output);
}

function array_multi_filter_download_empty($var) {
	if( is_array($var) ) {
		$var = @array_filter($var);
		return ($var & !empty($var));
	} else {
		return $var;
	}
}

function array_filter_download_links($var) {
	return (is_numeric($var));
}

function catch_that_image() {
	global $post, $posts;
	$first_img = '';
	ob_start();
	ob_end_clean();
	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
	$first_img = $matches[1][0];
	return $first_img;
}

function excerpt($limit){
	$excerpt = explode(' ', get_the_excerpt(), $limit);
    if(count($excerpt)>=$limit) {
		array_pop($excerpt);
		$excerpt = implode(" ",$excerpt).'...';
	} else {
		$excerpt = implode(" ",$excerpt);
	} 
	$excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
	return $excerpt;
}


function getPostViews($postID) {
	global $wpdb;
	$px_views = ( get_post_meta( $postID, 'px_views', true ) ? get_post_meta( $postID, 'px_views', true ) : 0 );
	return $px_views;	
}

function setPostViews($postID) {
	global $wpdb;
	$px_views = ( get_post_meta( $postID, 'px_views', true ) ? get_post_meta( $postID, 'px_views', true ) : 0 );
	update_post_meta( $postID, 'px_views', ($px_views + 1) );
}

function px_comment_nav() {
	if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
	?>
	<nav class="navigation comment-navigation" role="navigation">
		<h2 class="screen-reader-text"><?php echo __( 'Navegación de comentarios', 'appyn' ); ?></h2>
		<div class="nav-links">
			<?php
				if ( $prev_link = get_previous_comments_link( __( 'Comentarios antiguos', 'appyn' ) ) ) :
					printf( '<div class="nav-previous">%s</div>', $prev_link );
				endif;

				if ( $next_link = get_next_comments_link( __( 'Comentarios más nuevos', 'appyn' ) ) ) :
					printf( '<div class="nav-next">%s</div>', $next_link );
				endif;
			?>
		</div>
	</nav>
	<?php
	endif;
}

function px_social($social) {
	if( $social == "facebook" ){
		$option = get_option( 'appyn_social_facebook' );
	}
	elseif( $social == "twitter" ){
		$option = get_option( 'appyn_social_twitter' );		
	}
	elseif( $social == "google+" ){
		$option = get_option( 'appyn_social_google+' );		
	}
	elseif( $social == "instagram" ){
		$option = get_option( 'appyn_social_instagram' );		
	}
	elseif( $social == "youtube" ){
		$option = get_option( 'appyn_social_youtube' );		
	}
	elseif( $social == "pinterest" ){
		$option = get_option( 'appyn_social_pinterest' );		
	}
	return $option;
}
function load_template_part($template_name, $part_name=null) {
    ob_start();
    get_template_part($template_name, $part_name);
    $var = ob_get_contents();
    ob_end_clean();
    return $var;
}

function options_report($i) {
	if( $i == 1 ) {
		return __("No funcionan los enlaces de descarga", "appyn");
	} elseif( $i == 2 ) {
		return __("Hay una nueva versión", "appyn");
 	} else {
		return __("Otros", "appyn");
	}
}

function px_the_content() {
	global $post;
	$content = get_the_content();
	$content = apply_filters('the_content', $content);
	$content = str_replace(']]>', ']]&gt;', $content);
	echo px_content_filter($content);
}

function px_noimage($bg = false) {
	$noimage = get_template_directory_uri().'/images/noimage.png';
	$color_theme = get_option( 'appyn_color_theme' );
	$color_theme_principal = get_option( 'appyn_color_theme_principal' );
	if( is_dark_theme_active() ) {
		$noimage = get_template_directory_uri().'/images/noimage-d.png';
	}
	
	if( $bg ) return $noimage;

	if( is_amp_px() ) {
		return '<amp-img src="'.$noimage.'" class="image-single" layout="responsive" width="150" height="150" alt="No image"></amp-img>';
	} else {
		if( appyn_options( 'lazy_loading') ) {
			return '<img data-src="'.$noimage.'" src="" width="150" height="150" alt="No image" class="lazyload">';
		} else {
			return '<img src="'.$noimage.'" width="150" height="150" alt="No image">';
		}
	}
}

function count_reports() {
	global $wpdb;
	$wpdb->get_results( "SELECT meta_value, post_id FROM ".$wpdb->prefix."postmeta WHERE meta_key = 'px_app_report' ORDER BY meta_id DESC" );
	return $wpdb->num_rows;
}

function appyn_options($option, $empty = false) {

	if( !empty(get_option('appyn_'.$option) ) ) {
		return get_option('appyn_'.$option);
	} else {
		return ( $empty ) ?  '' : '0';
	}
}

function get_datos_download(){
	global $post;
	$datos_download = get_post_meta($post->ID, 'datos_download', true); 
	if( !empty($datos_download) ) { 
		$datos_download = array_filter($datos_download, 'array_multi_filter_download_empty');
	}
	return $datos_download;
}

function get_datos_info($key, $key_ = false){
	global $post;
	$di = get_post_meta($post->ID, 'datos_informacion', true); 
	if( !empty($di) ) { 
		$di = array_filter($di, 'array_multi_filter_download_empty');

		if( $key_ ) 
			return (isset($di[$key][$key_])) ? $di[$key][$key_] : '';
		else 
			return (isset($di[$key])) ? $di[$key] : '';
	}
}

function category_parents(){
	global $post;
    $category = get_the_category();
    $catid = $category[0]->cat_ID;
    $separador = " / ";
    $category_parents = get_category_parents( $catid, TRUE, "$separador", FALSE );
	$category_parents = explode($separador, $category_parents);
	if( is_array($category_parents) ) {
		$category_parents = array_filter($category_parents, 'array_multi_filter_download_empty');
		return $category_parents;
	}
}

function go_curl($url) {	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
	curl_setopt($ch, CURLOPT_REFERER, get_site_url());
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       
	$content = curl_exec($ch);
	curl_close($ch);
	
	return $content;
}

function is_amp_px() {
	$amp = appyn_options( 'amp' );
	if( $amp ) {
		return get_query_var( AMP_QUERY_VAR, false ) !== false;
	}
}

function amp_comment_form(){
	global $post;
	echo '<p><a href="'.esc_url( remove_query_arg( 'amp', get_the_permalink( $post->ID ) ) ).'#comment">'.__( 'Deja un comentario', 'appyn' ).'</a></p>';
}

function px_amp_logo($logo_url) {
	return '<amp-img src="'.$logo_url.'" alt="'.get_bloginfo('title').'" layout="fixed-height" height="40"></amp-img>';
}

function appyn_comment($comment, $args, $depth) {
    if ( 'div' === $args['style'] ) {
        $tag       = 'div';
        $add_below = 'comment';
    } else {
        $tag       = 'li';
        $add_below = 'div-comment';
    }?>
    <<?php echo $tag; ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?> id="comment-<?php comment_ID() ?>"><?php 
    if ( 'div' != $args['style'] ) { ?>
        <div id="div-comment-<?php comment_ID() ?>" class="comment-body"><?php
    } ?>
        <div class="comment-author vcard"><?php 
            if ( $args['avatar_size'] != 0 ) {
				if( is_amp_px() ) {
               		echo '<amp-img src="'.get_avatar_url( $comment, $args['avatar_size'] ).'" width="56" height="56"></amp-img>';
				} else {
               		echo get_avatar( $comment, $args['avatar_size'] );
				} 
            } 
            printf( '<cite class="fn">%s</cite> <span class="says">'.__( 'dice', 'appyn' ).':</span>', get_comment_author_link() ); ?>
        </div><?php 
        if ( $comment->comment_approved == '0' ) { ?>
            <em class="comment-awaiting-moderation"><?php echo __( 'Tu comentario está en espera de aprobación.', 'appyn' ); ?></em><br/><?php 
        } ?>
        <div class="comment-meta commentmetadata">
            <a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>"><?php
                printf( 
                    __( '%1$s a las %2$s', 'appyn' ), 
                    get_comment_date(),  
                    get_comment_time() 
                ); ?>
            </a><?php 
            edit_comment_link( __( '(Editar)', 'appyn' ), '  ', '' ); ?>
        </div>

        <?php comment_text(); ?>

        <div class="reply"><?php 
                comment_reply_link( 
                    array_merge( 
                        $args, 
                        array( 
                            'add_below' => $add_below, 
                            'depth'     => $depth, 
                            'max_depth' => $args['max_depth'] 
                        ) 
                    ) 
                ); ?>
        </div><?php 
    if ( 'div' != $args['style'] ) : ?>
        </div><?php 
    endif;
}

function px_post_thumbnail( $size = 'thumbnail', $post = NULL, $bg = false ) {
	if( !$post ) {
		global $post;
	}
	$output = px_post_status();
	$image = ($bg) ? px_noimage(true) : px_noimage();
    if( has_post_thumbnail() ) {
        $featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );
        if  ( ! empty( $featured_image_url ) ) {
			$gtpt = get_the_post_thumbnail($post->ID, $size);
			if( $bg ) {
				$gtpt = get_the_post_thumbnail_url($post->ID, $size);
			}
       		if  ( ! empty( $gtpt ) ) {
				$image = $gtpt;
			}
        } 
	}
	if( $bg ) {
		if( is_amp_px() ) {
			$output .= '<div class="image-single" style="background-image:url('.$image.');"></div>';
		} else {
			if( appyn_options( 'lazy_loading') ) {
				$output .= '<div class="image-single lazyload" data-bgsrc="'.$image.'""></div>';
			} else {
				$output .= '<div class="image-single" style="background-image:url('.$image.');"></div>';
			}
		}
	} else {
		$output .= $image;
	}
	return $output;
}

function px_content_filter($content){
	if( is_amp_px() ) {
		// Imágenes
		$re = '/<img(.*?)src=(\'|\")(.*?)(\'|\")(.*?)(\/)?>/m';
        preg_match_all($re, $content, $matches, PREG_SET_ORDER, 0);
        $images = array();
        foreach( $matches as $m ) {
            if( strpos($m[0], 'width=') === false ) {
				ob_start(); 
				$data = getimagesize(str_replace(get_site_url(), $_SERVER['DOCUMENT_ROOT'], $m[3]));
				$data = ob_get_clean(); 
				list($width, $height) = $data;
				if( !empty($width) ) {
					$subst = '<amp-img$1src=$2$3$4$5 layout="responsive" width="'.$width.'" height="'.$height.'"></amp-img>';
				} else { 
					list($width, $height) = getimagesize($m[3]);
					$subst = '<amp-img$1src=$2$3$4$5 layout="responsive" width="'.$width.'" height="'.$height.'"></amp-img>';
				}
                $images[$m[0]] = preg_replace($re, $subst, $m[0]);
            } else {
				ob_start(); 
				$data = getimagesize(str_replace(get_site_url(), $_SERVER['DOCUMENT_ROOT'], $m[3]));
				$data = ob_get_clean(); 
				list($width, $height) = $data;
				if( !empty($width) ) {
					$subst = '<amp-img$1src=$2$3$4$5 layout="responsive" style="max-width:'.$width.'px"></amp-img>';
					$images[$m[0]] = preg_replace($re, $subst, $m[0]);
				} else {
					list($width, $height) = getimagesize($m[3]);
					$subst = '<amp-img$1src=$2$3$4$5 layout="responsive" style="max-width:'.$width.'px"></amp-img>';
					$images[$m[0]] = preg_replace($re, $subst, $m[0]);
				}
            }
        }
        $content = strtr($content, $images);

		$videos = array();
		$re = '/<iframe.+?src="https?:\/\/www\.youtube\.com\/embed\/([a-zA-Z0-9_-]{11})"[^>]+?><\/iframe>/ms';
		preg_match_all($re, $content, $matches, PREG_SET_ORDER, 0);
		foreach( $matches as $v ) {
			$videos[$v[0]] = '<amp-youtube data-videoid="'.$v[1].'" layout="responsive" width="480" height="270"></amp-youtube>';
		}
		$content = strtr($content, $videos);

		$re = '/<script(.*?)<\/script>/ms';

		$content = preg_replace($re, '', $content);

		return $content;
	}
	return $content;
}

function lang_object_ids($object_id, $type) {
    $current_language= apply_filters( 'wpml_current_language', NULL );
    if( is_array( $object_id ) ){
        $translated_object_ids = array();
        foreach ( $object_id as $id ) {
            $translated_object_ids[] = apply_filters( 'wpml_object_id', $id, $type, true, $current_language );
        }
        return $translated_object_ids;
    } else {
		return apply_filters( 'wpml_object_id', $object_id, $type, true, $current_language );
	}
}

function app_developer(){
	global $post;
	$datos_informacion = get_post_meta($post->ID, 'datos_informacion', true);
	$output = '<span class="developer">';
	if( isset($datos_informacion['desarrollador'] ) ) {
		$output .= $datos_informacion['desarrollador'];
	} else {
		$dev_terms = wp_get_post_terms( $post->ID, 'dev', array('fields' => 'all'));
		if( !empty($dev_terms) ) {
			$output .= $dev_terms[0]->name;
		}
	}
	$output .= '</span>';
	return $output;
}

function app_date(){
	global $post;
	$appyn_post_date = appyn_options( 'post_date' );
	$appyn_post_date_type = appyn_options( 'post_date_type' );
	if( !$appyn_post_date ) return; 

	$date = get_the_date( get_option( 'date_format' ), $post->ID);
	if( $appyn_post_date_type == 1 ) {
		$date_change = array(
			'enero' => '01',
			'febrero' => '02',
			'marzo' => '03',
			'abril' => '04',
			'mayo' => '05',
			'junio' => '06',
			'julio' => '07',
			'agosto' => '08',
			'setiembre' => '09',
			'octubre' => '10',
			'noviembre' => '11',
			'diciembre' => '12',
			' de ' => '-',
		);
		$inf = get_post_meta( $post->ID, 'datos_informacion', true );
		if( !empty($inf['fecha_actualizacion']) ) {
			$date = date_i18n( get_option( 'date_format' ), strtotime(strtr($inf['fecha_actualizacion'], $date_change)));
		}
	}
	$output = '<span class="app-date">'.$date.'</span>';
	return $output;
}

function cover_header() {
	$arrayimgs = array();
	for($n=1;$n<=5;$n++){
		$option = appyn_options( 'image_header'.$n);
		if( !empty($option) )
			$arrayimgs[] = appyn_options( 'image_header'.$n);	
	}

	if( appyn_options( 'lazy_loading') ) {
		return '<img src="'.get_template_directory_uri().'/images/blank-d.png" data-src="'.$arrayimgs[rand(0,(count($arrayimgs) - 1))].'" alt="Portada" class="lazyload">';
	} else {
		return '<img src="'.$arrayimgs[rand(0,(count($arrayimgs) - 1))].'" alt="Portada">';
	}
}

function get_remote_html( $url ) {
	$response = wp_remote_get( $url );
	if ( is_wp_error( $response ) ) {
		return;
	}
	$html = wp_remote_retrieve_body( $response );
	if ( is_wp_error( $html ) ) {
		return;
	}
	return $html;
}

function activate_versions_boxes($caja) {
	$cvn = (get_option('appyn_versiones_no_cajas')) ? get_option('appyn_versiones_no_cajas') : array(1);

	if( !in_array( $caja, $cvn ) ) {
		return true; 
	}
}

function activate_internal_page_boxes($caja) {
	$cvn = (get_option('appyn_pagina_interna_no_cajas')) ? get_option('appyn_pagina_interna_no_cajas') : array(1);

	if( !in_array( $caja, $cvn ) ) {
		return true; 
	}
}

function download_links_normal() {
	$option_download = get_option( 'appyn_download_links' );
	if( $option_download == 0 )
		return true;
}

function link_button_download_apk() {
	global $post;

	$datos_download = get_datos_download();
	$option_download = get_option( 'appyn_download_links' );

	if( empty($datos_download['option']) ) { 

		if( !empty($datos_download[0]['link']) ) { 
			return ( ( $option_download == 1 ) ? add_query_arg('download', 'links', esc_url(remove_query_arg('amp')) ) : '#download');
		}
		

	} elseif( $datos_download['option'] == "links" && count($datos_download) > 1 ){

		if( !empty($datos_download[0]['link']) ) { 
			return ( ( $option_download == 1) ? add_query_arg('download', 'links', esc_url(remove_query_arg('amp'))) : '#download' );
		}

	} 
	elseif( $datos_download['option'] == "direct-link" ){
		
		if( !empty($datos_download['direct-link']) ) { 
			return ( ( $option_download == 1 ) ? add_query_arg('download', 'redirect', esc_url(remove_query_arg('amp'))) : $datos_download['direct-link'] );
		}

	} 
	elseif( $datos_download['option'] == "direct-download" ){

		if( !empty($datos_download['direct-download']) ) { 
			return ( ( $option_download == 1 ) ? add_query_arg('download', 'true', esc_url(remove_query_arg('amp'))) : $datos_download['direct-download'] ); 
		}

	}
}

function px_data_structure() {
	global $post;
	if( is_singular('post') ) {
		$rating = count_rating($post->ID);
		if( $rating['average'] > 0 ) {
			$datos_informacion = get_post_meta($post->ID, 'datos_informacion', true); 
			$price = ( (!isset($datos_informacion['offer']['price']) || @$datos_informacion['offer']['price'] == "gratis") ? '0' : $datos_informacion['offer']['price'] );
			$currency = 0;

			if( $price == "pago" ) {
				$price = @$datos_informacion['offer']['amount'];
				$currency = @$datos_informacion['offer']['currency'];
			}

			$os = (empty(@$datos_informacion['os'])) ? 'ANDROID' : @$datos_informacion['os'];

			$cat = ( !isset($datos_informacion['categoria_app']) ? 'GameApplication' : $datos_informacion['categoria_app'] );

			$code = '<script type="application/ld+json">
				{
				"@context": "http://schema.org",
				"@type": "SoftwareApplication",
				"name": "'.get_the_title().'",
				"operatingSystem": "'.$os.'",
				"applicationCategory": "http://schema.org/'.$cat.'",
				"aggregateRating": {
					"@type": "AggregateRating",
					"ratingValue": "'.$rating['average'].'",
					"ratingCount": "'.str_replace(',','',$rating['users']).'"
				},
				"offers": {
					"@type": "Offer",
					"price": "'.$price.'",
					"priceCurrency": "'.$currency.'"
				}
				}
				</script>';
				echo str_replace(array("\n", "\t"), '', $code);
		}
		

		$cat = get_the_category();
		if( !empty($cat[0]) ) {
			$pos = 1;
			echo '<script type="application/ld+json">
					{
					"@context": "https://schema.org",
					"@type": "BreadcrumbList",
					"itemListElement": [';
			if( $cat[0]->category_parent ) {
				$cat_parent = get_term_by('id', $cat[0]->category_parent, 'category');
			echo '{
					"@type": "ListItem",
					"position": '.$pos++.',
					"name": "'.$cat_parent->name.'",
					"item": "'.get_term_link($cat[0]->category_parent).'"
				},';
			}
			echo '{
					"@type": "ListItem",
					"position": '.$pos++.',
					"name": "'.$cat[0]->name.'",
					"item": "'.get_term_link($cat[0]->term_id).'"
				}';

			echo ']
				}
			</script>';
		}
	}
}

function get_store_app() {
	global $post;
	$datos_informacion = get_post_meta($post->ID, 'datos_informacion', true);
	$output = '';
	if( !is_array($datos_informacion) ) return;

	if( strpos($datos_informacion['consiguelo'], 'microsoft.com') !== false ) {
		if( is_amp_px() ) {
			$output = '<amp-img src="'.get_template_directory_uri().'/images/windows.png" width="120" height="38" alt="Windows Store"></amp-img>'; 
		} else {
			$output = '<img src="'.get_template_directory_uri().'/images/windows.png" alt="Windows Store">';
		}
	}
	elseif( strpos($datos_informacion['consiguelo'], 'apps.apple.com') !== false ) {
		if( is_amp_px() ) {
			$output = '<amp-img src="'.get_template_directory_uri().'/images/appstore.png" width="120" height="36" alt="App Store"></amp-img>'; 
		} else {
			$output = '<img src="'.get_template_directory_uri().'/images/appstore.png" alt="App Store">';
		}
	} else {
		if( is_amp_px() ) {
			$output = '<amp-img src="'.get_template_directory_uri().'/images/googleplay.png" width="120" height="27" alt="Google Play"></amp-img>'; 
		} else {
			$output = '<img src="'.get_template_directory_uri().'/images/googleplay.png" alt="Google Play">';
		}
	}
	return $output;
}

function px_pay_app() {
	global $post;
	$datos_informacion = get_post_meta($post->ID, 'datos_informacion', true);

	if( !isset($datos_informacion['offer']['price']) ) return;

	if( $datos_informacion['offer']['price'] != "pago" ) return;

	if( empty($datos_informacion['offer']['amount']) ) {	
		return '<ul class="amount-app">
			<li>'.__( 'De pago', 'appyn' ).'</li>
		</ul>';
	} else {
		return '<ul class="amount-app">
	<li>'.$datos_informacion['offer']['amount'].' '.$datos_informacion['offer']['currency'].'</li>
</ul>';
	}
}

function px_check_apk_obb($data) {

	if( count($data) != 2 ) return false;

	return ( array_key_exists('apk', $data) && array_key_exists('obb', $data) ) ? true : false;
}

function px_upload_apk($post_id, $idps, $apk, $update){

	if( px_check_apk_obb($apk) ) {
		$uploaddir = wp_upload_dir();
		$da = "-".( !empty($update) ? date('d-m-Y', $update) : 1);
		$tm = sanitize_title(get_site_url());
		$lsa = px_last_slug_apk();
		$filename = sanitize_title($idps)."{$da}{$lsa}.zip";
		$uploadfile = $uploaddir['path'] . '/' . $filename;

		$temp_zip = tempnam("/tmp", "zip");
		$zip = new ZipArchive();
		$zip->open($temp_zip, ZipArchive::OVERWRITE);
		foreach ($apk as $type => $f) {
			$fname = sanitize_title($idps).".{$type}";

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_URL, $f);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       
			$contents = curl_exec($ch);
			curl_close($ch);

			$zip->addFromString($fname, $contents );
		}
		$zip->close();
	
		if ( appyn_options('edcgp_sapk_server') == 2 ) {

			// Subir mediante Gdrive

			$client = get_Client();
			copy($temp_zip, $uploadfile);
			$d = appyn_options( 'gdrive_folder', true );
			$folder_id = ($d) ? px_create_folder( $d ) : null;
			$success = px_insert_file_to_drive( $uploaddir['url'].'/'.$filename, $filename, $folder_id);
			$datos_download['option'] = 'links';
			$datos_download[0]['link'] = $success;
			$datos_download[0]['texto'] = 'Link';
			$datos_download['type'] = 'apk_obb';
			unlink($uploadfile);
		} else {			

			// Subir mediante WP
		
			if( !file_exists($uploadfile) ) {
				$wp_filetype = wp_check_filetype(basename($filename), null );
				$attachment = array(
					'post_mime_type' => $wp_filetype['type'],
					'post_title' => $filename,
					'post_content' => '',
					'post_status' => 'inherit'
				);

				wp_insert_attachment( $attachment, $uploadfile, $post_id );
			}
			copy($temp_zip, $uploadfile);
			$datos_download = get_post_meta( $post_id, 'datos_download', true );
			$datos_download = ( !empty($datos_download) ) ? $datos_download : array(); 
			$datos_download['option'] = 'links';
			$datos_download[0]['link'] = $uploaddir['url']."/".$filename;
			$datos_download[0]['texto'] = 'Link';
			$datos_download['type'] = 'apk_obb';
		}
		unlink($temp_zip); 

	} else {
		foreach( $apk as $type => $file ) {
			$ext = ".apk";
			if( $type == "zip" ) {
				$ext = ".zip";
			}
			$uploaddir = wp_upload_dir();
			$da = "-".( !empty($update) ? date('d-m-Y', $update) : 1);
			$lsa = px_last_slug_apk();
			$filename = sanitize_title($idps)."{$da}{$lsa}{$ext}";
				
			if ( appyn_options('edcgp_sapk_server') == 2 ) {

				// Subir mediante Gdrive

				$client = get_Client();
				$d = appyn_options( 'gdrive_folder', true );
				$folder_id = ($d) ? px_create_folder( $d ) : null;
				$success = px_insert_file_to_drive( $file, $filename, $folder_id);
				$datos_download['option'] = 'links';
				$datos_download[0]['link'] = $success;
				$datos_download[0]['texto'] = 'Link';
				$datos_download['type'] = $type;

			} else {			
				// Subir mediante WP

				$uploadfile = $uploaddir['path'] . '/' . $filename;
				
				if( !file_exists($uploadfile) ) {
					$wp_filetype = wp_check_filetype(basename($filename), null );
					$attachment = array(
						'post_mime_type' => $wp_filetype['type'],
						'post_title' => $filename,
						'post_content' => '',
						'post_status' => 'inherit'
					);

					wp_insert_attachment( $attachment, $uploadfile, $post_id );
				}
				copy($file, $uploadfile);

				$datos_download = get_post_meta( $post_id, 'datos_download', true );
				$datos_download = ( !empty($datos_download) ) ? $datos_download : array(); 
				$datos_download['option'] = 'links';
				$datos_download[0]['link'] = $uploaddir['url']."/".$filename;
				$datos_download[0]['texto'] = 'Link';
				$datos_download['type'] = $type;
			}
		}
	}

	update_post_meta( $post_id, 'datos_download', $datos_download );
}

function get_http_response_code($url) {
	$args = array(
        'sslverify'   => false,
    );

    $request = wp_remote_get( $url, $args );

    if ( wp_remote_retrieve_response_code( $request ) == 200 ) {
		return true;
	}
}

function slugify($text) {
	global $url_app;
	$re = '/[^A-Za-z0-9-]+/m';
	preg_match_all($re, $text, $matches, PREG_SET_ORDER, 0);
	if( count($matches) > 0 ) {
		$re = '/\?id=com\.([a-zA-Z\.]+)/ms';
		preg_match_all($re, $url_app, $matches, PREG_SET_ORDER, 0);
		$nombre = $matches[0][1];
	} else {
		$nombre = $text;
	}
  	return $nombre;
}

function px_upload_image() {
    global $datos, $post_id, $url_app;
	$image = $datos['imagecover'];
	$nombre = slugify(sanitize_title(strip_tags(wp_staticize_emoji($datos['nombre']))));
	
	$uploaddir = wp_upload_dir();
	$filename = "{$nombre}.png";
	$uploadfile = $uploaddir['path'] . '/' . $filename;

	if( !file_exists($uploadfile) ) {
		$wp_filetype = wp_check_filetype(basename($filename), null );
		$attachment = array(
			'post_mime_type' => $wp_filetype['type'],
			'post_title' => $filename,
			'post_content' => '',
			'post_status' => 'inherit'
		);

		$attach_id = wp_insert_attachment( $attachment, $uploadfile );
	} else {
		$attach_id = attachment_url_to_postid($uploaddir['url'].'/'.$filename);
	}
	copy($image, $uploadfile);

	require_once(ABSPATH . 'wp-admin/includes/image.php');
	$attach_data = wp_generate_attachment_metadata( $attach_id, $uploadfile );
	wp_update_attachment_metadata( $attach_id, $attach_data );

	set_post_thumbnail( $post_id, $attach_id );
}

function versions_permalink() {
	if( is_amp_px() ) {
		return esc_url( rtrim(remove_query_arg('amp', get_permalink()), '/')."/versions/?amp=1" );
	} else {
		return esc_url( rtrim(get_permalink(), '/')."/versions/" );
	}
}

function px_nav_menu( $type = '' ) {

	$c = '';
	$button_light_dark = '';

	$option_color_theme_user_select = appyn_options( 'color_theme_user_select' );
	if( $option_color_theme_user_select == 1 ) {
		if( is_dark_theme_active() )
			$c = ' class="active"';
			
		$button_light_dark = '<div id="button_light_dark"'.$c.'><i class="fa fa-lightbulb-o" aria-hidden="true"></i></div>';
	}

	$args = array(
		'show_home' => true, 
	);
	if( $type == "mobile" ) {

		$args['theme_location'] = 'menu-mobile';
		$args['container'] = '';
		$args['items_wrap'] = '<ul id="%1$s" class="%2$s">%3$s <li>'.px_header_social().'</li></ul>'.$button_light_dark.'';

	} else {

		$args['theme_location'] = 'menu';
		$args['container'] = 'nav';
		$args['items_wrap'] = '<div class="menu-open"><i class="fa fa-bars" aria-hidden="true"></i></div><ul id="%1$s" class="%2$s">%3$s</ul>'.$button_light_dark.'';

	}
	
	wp_nav_menu( $args );
}

function px_blog_postmeta() {
	global $post;
	?>
	<div class="meta">
		<span><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php the_time(get_option( 'date_format' )); ?></span> <span><i class="fa fa-user" aria-hidden="true"></i> <?php the_author_link(); ?></span>
		<?php 
		if( get_the_term_list( $post->ID, 'cblog' ) ) {
		?>
		<span><i class="fa fa-folder" aria-hidden="true"></i> <?php echo get_the_term_list( $post->ID, 'cblog', '', ', ' ); ?></span> 
		<?php } ?>
		<span><i class="fa fa-comments-o" aria-hidden="true"></i> <?php comments_number(); ?></span>
	</div>
	<?php
}

function px_post_status() {
	global $post;
	$inf = get_post_meta( $post->ID, 'datos_informacion', true );
	if( isset($inf['app_status']) ) {
		if( $inf['app_status'] == 'new' ) {
			if( date('U') <= date('U', strtotime($post->post_date. '+ 2 weeks')) )
				return '<div class="bloque-status bs-new">'.__( 'Nuevo', 'appyn' ).'</div>';
		}
		elseif( $inf['app_status'] == 'updated' ) {
			if( date('U') <= date('U', strtotime($post->post_date. '+ 2 weeks')) )
			return '<div class="bloque-status bs-update">'.__( 'Actualizado', 'appyn' ).'</div>';
		}
	} 
}

function get_Client() {
	$a = appyn_options( 'gdrive_client_id', true );
	$b = appyn_options( 'gdrive_client_secret', true );

	if( !$a && !$b ) return false;

	require_once __DIR__.'/google-api-php-client-master/vendor/autoload.php';

	$redirect_uri = get_site_url();

	$config = [
		'client_id' 	=> $a,
		'client_secret' => $b,
		'redirect_uri' 	=> $redirect_uri
	];
	$client = new Google_Client($config);
	$client->setScopes(Google_Service_Drive::DRIVE);
	$client->setAccessType('offline');
	$client->setPrompt('select_account consent');

	if (get_option('appyn_gdrive_token')) {
		$accessToken = json_decode(get_option('appyn_gdrive_token'), true);
		$client->setAccessToken($accessToken);
	}

	if ($client->isAccessTokenExpired()) {
		if ($client->getRefreshToken()) {
			$client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
		} 
		$gat = ( $client->getAccessToken() ) ? $client->getAccessToken() : null;
		if( $gat ) 
			update_option('appyn_gdrive_token', json_encode($client->getAccessToken()));
	}

	return $client;
}

function px_create_folder( $folder_name, $parent_folder_id=null ){
	$client = get_Client();
    $folder_list = px_check_folder_exists( $folder_name );

    if( count( $folder_list ) == 0 ){
        $service = new Google_Service_Drive( $client );
        $folder = new Google_Service_Drive_DriveFile();
    
        $folder->setName( $folder_name );
        $folder->setMimeType('application/vnd.google-apps.folder');
        if( !empty( $parent_folder_id ) ){
            $folder->setParents( [ $parent_folder_id ] );        
        }

        $result = $service->files->create( $folder );
    
        $folder_id = null;
        
        if( isset( $result['id'] ) && !empty( $result['id'] ) ){
            $folder_id = $result['id'];
        }
    
        return $folder_id;
    }

    return $folder_list[0]['id'];
}

function px_check_folder_exists( $folder_name ){
	$client = get_Client();
    $service = new Google_Service_Drive($client);

    $parameters['q'] = "mimeType='application/vnd.google-apps.folder' and name='$folder_name' and trashed=false";
    $files = $service->files->listFiles($parameters);

    $op = [];
    foreach( $files as $k => $file ){
        $op[] = $file;
    }

    return $op;
}

function px_insert_file_to_drive( $file_path, $file_name, $parent_file_id = null ){
	$client = get_Client();
    $service = new Google_Service_Drive($client);
    $file = new Google_Service_Drive_DriveFile();

    $file->setName( $file_name );

    if( !empty( $parent_file_id ) ){
        $file->setParents( [ $parent_file_id ] );        
    }
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_REFERER, 'https://googleapis.apk.services/');
	curl_setopt($ch, CURLOPT_URL, $file_path);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       
	$contents = curl_exec($ch);
	curl_close($ch);

    $result = $service->files->create(
        $file,
        array(
            'data' => $contents,
            'mimeType' => 'application/octet-stream',
        )
    );

    $is_success = false;
    
    if( isset( $result['name'] ) && !empty( $result['name'] ) ){
        $is_success = true;
        
        $newPermission = new Google_Service_Drive_Permission();
        $newPermission->setType('anyone');
        $newPermission->setRole('reader');
        try {
            $service->permissions->create($result['id'], $newPermission);
        } 
        catch (Exception $e) {
            print "An error occurred: " . $e->getMessage();
        }
    }

    $link = 'https://drive.google.com/file/d/'.$result['id'].'/view?usp=sharing';
    $link_download = 'https://drive.google.com/uc?export=download&id='.$result['id'].'';

    return $link_download;
}

function px_info_install() {
	global $post;

	$d = get_datos_download();
	$a = str_replace('[Title]', $post->post_title, appyn_options( 'apps_info_download_apk', true ));
	$b = str_replace('[Title]', $post->post_title, appyn_options( 'apps_info_download_zip', true ));

	if( !empty($a) || !empty($b) ) {

		$output = '<div class="bx-info-install">';

		if( $d['type'] == 'apk' )
			$output .= wpautop($a);
		elseif( $d['type'] == 'zip' || $d['type'] == 'apk_obb' )
			$output .= wpautop($b);    

		$output .= '</div>';

		return $output;
	}
}

function px_last_slug_apk() {
	$lsa = appyn_options( 'edcgp_sapk_slug', true ); 
	return ( $lsa ) ? '-'.$lsa : '';
}